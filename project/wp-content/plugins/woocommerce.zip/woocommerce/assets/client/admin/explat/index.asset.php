<?php return array('dependencies' => array('react', 'wp-api-fetch', 'wp-hooks'), 'version' => '905d5d5b0f90753d5639');
